If the source database is part of pass replication but the target database is not part of replication, 
we need to perform below steps along with the above steps.

1. Input
Customer Name
Product
source servername, db name  ##tsaa050303001, wmswlmmp
target servername, db name  ##tsaa050303002, wmsmp ##Most of the scenario source and target db name will be same; if not select and replace accordingly 
SF Case
Source and Target DB backup need to be configure in the same RSV #Check on Azure
Before refresh, need to take backup of soruce and target db backup 
#Most scenarios existing backup of source will be used. In that case file path of source db to be provided; Check with azure team for existing locations
Backup [Full, Full & Differential]

2. Precheck (Same for Standalone or AlwaysOn)
->SQL version check from source & target - if the source is higher version and target is lower version, db refresh will not proceed
#SQL Query
select @@version 
SERVERPROPERTY ('productversion'))

->Disk space available target server (H:,G:,I:)( & db size using SQL Command)- if the free space is not available, db refresh activity will not proceed
	I: drive -> for backup
	G: drive -> for logs/DB files drive
	H: drive -> DB files drive

	exec sp_helpdb 'wmswlmmp' -> in source and find the db size.
	based on the db size the drive space availability is checked before proceeding

->Azure RSV need to be run on the source and Target server
	AzureWLBackupCoordinatorSvc #Should be running
	AzureWLBackupInquirySvc
	AzureWLBackupPluginSvc #Should be running
Doubt -> To confirm all the 3 service should be running or AzureWLBackupCoordinatorSvc is fine? #To be confirmed by azure platform team #DL - CS-AzurePlatFormSupport or ping Mohamed Yaser Arafath

Types (target) -> Standalone or AlwaysOn
#Query by mark
Show listener name for SQL always ON servers
SELECT replica_server_name, role_desc, dns_name FROM master.sys.availability_replicas ar
JOIN master.sys.availability_group_listeners agl ON ar.group_id = agl.group_id
JOIN master.sys.dm_hadr_availability_replica_states ars ON ar.replica_id = ars.replica_id
#    this will show if its alwayson configured
​#    if its not configured u will not see the listener name

##### Query by satya
declare @IsHadrEnabled as sql_variant set @IsHadrEnabled = (select SERVERPROPERTY('IsHadrEnabled'))
select @IsHadrEnabled as IsHadrEnabled,
case @IsHadrEnabled
when 0 then 'The Always On availability groups is disabled'
when 1 then 'The Always On availability groups is enabled'
else 'Invalid Input'
end as 'Hadr'
##To be confirmed with Mark
#If Alwayson -> Check for primary/passive node/db

SQL Standalone
--------------
-> Application was taken offline -- 
-> Check any active Connection on DB - SQL Query (only on target)
	/****/select a.* from master..sysprocess a,	master..sysdatabases b where a.dbid=b.dbid and b.name='targetdbname';

	select * from sys.sysprocesses a, master..sysdatabases b where a.dbid=b.dbid and b.name='Email_Notification';


	If any active connection, kill and check again - SQL Query
	/****/kill 61 #spid
	If still any active connection found, Dont proceed and send email to requestor/Application team
	
	No connection found, proceed with DB source/target db backup in RSV - if restor mentioned in input

-> Source Target/Backup

-> Option to select existing backup/take new backup
	1. Select existing backup []??? - from where
		#Azure platform team to provide the query or script to select existing backup
		#Check whether able to access the file and procced

	2. Taking backup of source to target db in RSV
		Open RSV -> Select the RSV -> select source db server -> Restore
		Inputs-> Alternate location, Target DB server, DB Name(wmswlmmp_datatime_stamp)  ##No need
		then select -> Restore as a file -> give destination path -> eg: I:/dnd_backup -> Select Restore point -> Differential -> Full& Differential -> select full backup/Differential [input from user]
		check for the backup job completion status

-> Restore database
Options -> Full backup, Full & Differential

Restore with recovery [Full backup] -> Will go with this option for now
Use [master]
 restore database [wmswlmmp] from
 disk = N'Path of backup file'
 with replace, recovery, keep_replication
Go

Restore with norecovery [Full & Differential]
Use [master]
 restore database [wmswlmmp] from
 disk = N'Path of backup file'
 with replace, norecovery, keep_replication
Go

#Check with Azure team -> How to restore using RSV in case of large files???????

Command to check restore status
Doubt -> SQL command to be provided

Excute the query -> Check the restore percent complete? to 100%?
Once restore completed -> the query will return no data and db will be online

Once restore is completed all the data including replication component will be copied follow the below steps to remove replication
-> Cleaned up Subscription entries on target 
exec DBNAME..sp_dropsubscription @publication = N'pulication_name', @subscriber = N'all', @destination_db = N'SUBSCRIBER DB', @article = N'all', @Ignore_Distributor = 1
#DBName ->
#Publication name ->
#Subscriber DB ->
Doubt -> Script/query to find all the 3?

-> Drop publication on target server 
 exec DBNAME..sp_droppublication @publication='PubName_To_PaaS_Tran', @ignore_distributor = 1
#DBName ->
#Publication name ->
-> Remove database from replication enablement
exec DBNAME..sp_replicationdboption @dbname = N'DBNAME', @optname = N'publish', @value = N'false'
#DBName ->
Doubt -> Any query to confirm replication is available/removed?

-> Fix users permissions
use wmswlmmp
go
exec sp_change_users_login 'auto_fix','hu_wmswlmmp'

#
Doubt -> how to find the customer readonly account? eg: bp_custro -> customername_custro find the list in the pattern and fix
and query to generate the script to fix permissions?

If Standalone & nonprod -> change recovery model to simple [when -> prod to nonprod]
USE [master]
go
alter database [wmswlmmp] set recovery simple with no_wait
go

#Check with mark for identifying prod and nonprod servers
Mark
----
Query to identify Standalone and AlwaysOn
If Alwayson -> Check for primary/passive node/db

Identify prod and non-prod env


Satya
-----
#DBName ->
#Publication name ->
#Subscriber DB ->

Script/query to find all the 3?
Query/Command to check restore status?
 

Azure platform team
-------------------
Most scenarios existing backup of source will be used. 
In that case file path of source db to be provided; 
Check with azure team for existing locations
--> \\sharepath for backup file

Doubt -> To confirm all the 3 service should be running or AzureWLBackupCoordinatorSvc is fine? 
#To be confirmed by azure platform team 
#DL - CS-AzurePlatFormSupport or ping Mohamed Yaser Arafath

1. Select existing backup []??? - from where
	#Azure platform team to provide the query or script to select existing backup
	#Check whether able to access the file and procced
in RSV -> Option -> Restore as file -> specify target server name and destination path and choose the date of backup
sample: 100gb -> 5-10min
		1tb -> 20-30min
Check with Azure team -> How to restore using RSV in case of large files???????
---------------------------------------------------
#Check How to point out existing backup from RSV to restore file
#Create serviceaccount for connecting with all servers - approval from Anil malkai and nihar panda
#Share the deadlines with tracker

Source may be Standalone or Alwayson -> Target to be Standalone




[3/19 7:57 PM] Satya Ranjan Dutta (CW)
    


use [pepwmwlmmpsr]
exec sp_dropsubscription @publication = N'ALL', @subscriber = N'ALL', @article = N'ALL', @ignore_distributor=1;
exec sp_droppublication @publication = N'ALL', @ignore_distributor=1
exec sp_replicationdboption @dbname = N'pepwmwlmmpsr', @optname = N'publish', @value = N'false'


​[3/19 7:58 PM] Satya Ranjan Dutta (CW)
    ********Below is the restore status query *********
​[3/19 7:58 PM] Satya Ranjan Dutta (CW)
    

SELECT  r.session_id [Session Id],
r.command [Command],

CONVERT(NUMERIC(6,2),r.percent_complete) AS [Percent Complete],
   CONVERT(VARCHAR(20),DATEADD(ms,r.estimated_completion_time,GetDate()),20) AS [ETA Completion Time],
   CONVERT(NUMERIC(10,2),r.total_elapsed_time/1000.0/60.0) AS [Elapsed Min],
   CONVERT(NUMERIC(10,2),r.estimated_completion_time/1000.0) AS [ETA Sec],
   CONVERT(NUMERIC(10,2),r.estimated_completion_time/1000.0/60.0) AS [ETA Min],
   CONVERT(NUMERIC(10,2),r.estimated_completion_time/1000.0/60.0/60.0) AS [ETA Hours],

CONVERT(VARCHAR(1000),(
SELECT  SUBSTRING(text,r.statement_start_offset/2,
CASE
WHEN r.statement_end_offset = -1 THEN 1000
ELSE (r.statement_end_offset-r.statement_start_offset)/2
END
) FROM sys.dm_exec_sql_text(sql_handle))) AS [SQL]
FROM    sys.dm_exec_requests r
WHERE   r.session_id > 50
and     r.session_id <> @@SPID
AND     command IN ('RESTORE DATABASE','BACKUP DATABASE','RESTORE LOG','BACKUP LOG')

