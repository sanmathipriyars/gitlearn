﻿$path="\\DLJDAMGMTROMINAS01.jdadelivers.com\ROMI_Share\profiles\1028742\Desktop\5_1_day"
$logdate = (get-date).ToString("dd-MMM-yyyy_hhmmss")
function Get-tz($tz)
{
    if($tz -eq "EST" -or $tz -eq "EDT")
    {
        $zone=[System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Eastern Standard Time" }
    }
    elseif($tz -eq "JST")
    {
        $zone=[System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Tokyo Standard Time"}
    }
    elseif($tz -eq "IST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "India Standard Time"}
    }
    elseif ($tz -eq "CES")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central Europe Standard Time"}
    }
    elseif ($tz -eq "CET")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central Europe Standard Time"}
    }
    elseif ($tz -eq "CST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central Standard Time"}
    }
    elseif ($tz -eq "AES")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "AUS Eastern Standard Time"}
    }
    elseif ($tz -eq "UTC")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "UTC"}
    }
    elseif ($tz -eq "GMT")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "GMT Standard Time"}
    }
    elseif ($tz -eq "BST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central European Standard Time"}
    }
    elseif ($tz -eq "PST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Pacific Standard Time"}
    }
    elseif ($tz -eq "SGT")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Singapore Standard Time"}
    }
    elseif ($tz -eq "brisbane")
    {
        $zone=[System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "E. Australia Standard Time"}
    }
    return $zone
}

Function Run-MySQLQuery  {

  Param(
        [Parameter(
            Mandatory = $true,
            ParameterSetName = '',
            ValueFromPipeline = $true)]
            [string]$query,   
    [Parameter(
            Mandatory = $true,
            ParameterSetName = '',
            ValueFromPipeline = $true)]
            [string]$connectionString          
        )
  Begin {
    #Write-Verbose "Starting Begin Section"   
    }
  Process {
    #Write-Verbose "Starting Process Section"
    try {
      # load MySQL driver and create connection
      Write-Verbose "Create Database Connection"
      # You could also could use a direct Link to the DLL File
       $mySQLDataDLL = "C:\Program Files (x86)\MySQL\MySQL Connector Net 8.0.22\Assemblies\v4.5.2\MySql.Data.dll"
       [void][system.reflection.Assembly]::LoadFrom($mySQLDataDLL)
      #[void][System.Reflection.Assembly]::LoadWithPartialName("MySql.Data") | Out-Null
      $connection = New-Object MySql.Data.MySqlClient.MySqlConnection
      $connection.ConnectionString = $ConnectionString
      #Write-Verbose "Open Database Connection"
      $connection.Open()      
      # Run MySQL Querys
      #Write-Verbose "Run MySQL Querys"
      $command = New-Object MySql.Data.MySqlClient.MySqlCommand($query, $connection)
      $dataAdapter = New-Object MySql.Data.MySqlClient.MySqlDataAdapter($command)
      $dataSet = New-Object System.Data.DataSet
      $recordCount = $dataAdapter.Fill($dataSet, "data")
      #$dataSet.Tables["data"] | Format-Table
            return $dataSet.Tables["data"]
    } 
  
    catch {
      #Write-Host "Could not run MySQL Query" $Error[0] 
    } 
    Finally {
      #Write-Verbose "Close Connection"
      $connection.Close()
    }
        }
  End {
    #Write-Verbose "Starting End Section"
  }
}
$ConnectionString = "Server=127.0.0.1;Uid=root;Pwd='';database=compliance_report;"
$5_day="SELECT Distinct customer_info.customer_name, customer_info.customer_maintance, customer_info.email_to, customer_info.email_cc, customer_info.email_bcc, customer_info.email_content, customer_info.system_service_affected, customer_info.status, customer_info.url, patch_info_new.patch_date, 
        (CASE 
        WHEN customer_info.e_id = '1' THEN 'Prod' 
        WHEN customer_info.e_id = '2' THEN 'Non-Prod' 
        END) AS env 
        FROM customer_info 
        inner join patch_info_new on customer_info.customer_name = patch_info_new.customer_name and customer_info.e_id=patch_info_new.e_id 
        WHERE (DATEDIFF( patch_info_new.patch_date,CONVERT(now(),date)) = 5)"
$5_data=@()
#$5_data = Run-MySQLQuery -query $5_day -connectionString $ConnectionString
$5_data=Import-Csv "$path\test.csv"
if($5_data)
{
    foreach($cus in $5_data)
    {
    $time=$cus.customer_maintance
    $date=$cus.patch_date
    $who=$cus.customer_name
    $sys=$cus.system_service_affected
    $urls=$cus.url
    $urlss=""

    if($urls)
    {
    $urls=$urls -replace ",",";"
    $urls=($urls -split ";")
    $count=1
    $tcount=$urls.count
        foreach($url in $urls)
        {
            if($count -eq $tcount)
            {
                $urlss+="<a>$url</a>"
            }
            else
            {
                $urlss+="<a>$url</a></br>"
            }
            $count++
        }
    }
    else
    {$urlss+="<p>&nbsp;</p>"}


    $from=$time -split " "
    $fromhr=[int]($from[0] -split ":")[0]
    $frommin=($from[0] -split ":")[1]
    $fromampm = $from[1]
    if ($fromampm -eq "AM")
    {
        if ($fromhr -eq 12)
        {
            $fromhr = 0
        }
    }
    elseif ($fromampm -eq "PM")
    {
        if ($fromhr -eq 12)
        {
            $fromhr=12
        }
        else
        {
            $fromhr += 12;
        }
    }

    if($fromampm -eq "PM" -and $toampm -eq "AM")
    {
        $todate=get-date ((Get-date $date).AddDays(1)) -Format "MM/dd/yyy"
    }
    else
    
    {
        $todate=get-date $date -Format "MM/dd/yyy"
    }

    $tohr=[int]($from[4] -split ":")[0]
    $tomin=[int]($from[4] -split ":")[1]
    $toampm=$from[5]
    if ($toampm -eq "AM")
    {
        if ($tohr -eq 12)
        {
            $tohr = 0
        }
    }
    elseif ($toampm -eq "PM")
    {
        if ($tohr -eq 12)
        {
            $tohr=12
        }
        else
        {
            $tohr += 12;
        }
    }
    $fromtime=Get-Date -Date $date -Hour "$fromhr" -Minute $frommin
    $totime=Get-Date -Date $todate -Hour "$tohr" -Minute $tomin

    $tz=$from[2]

    $fromtzone=Get-tz -tz $tz

    #Coordinated Universal Time
    $t1= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "UTC" }
    $t1_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t1)
    $t1_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t1)
    $time1="$($t1_time_start.ToString("MM/dd/yyy hh:mm tt")) to $($t1_end_time.ToString("hh:mm tt"))"

    #Dublin, Edinburgh, Lisbon, London
    $t2= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "GMT Standard Time" }
    $t2_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t2)
    $t2_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t2)
    $time2="$($t2_time_start.ToString("MM/dd/yyy hh:mm tt")) to $($t2_end_time.ToString("hh:mm tt"))"

    #Brussels, Copenhagen, Madrid, Paris
    $t3= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "Romance Standard Time" }
    $t3_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t3)
    $t3_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t3)
    $time3="$($t3_time_start.ToString("MM/dd/yyy hh:mm tt")) to $($t3_end_time.ToString("hh:mm tt"))"

    #Indian Standard Time
    $t4= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "India Standard Time" }
    $t4_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t4)
    $t4_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t4)
    $time4="$($t4_time_start.ToString("MM/dd/yyy hh:mm tt")) to $($t4_end_time.ToString("hh:mm tt"))"

    #Tokyo Standard Time
    $t5= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Tokyo Standard Time" }
    $t5_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t5)
    $t5_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t5)
    $time5="$($t5_time_start.ToString("MM/dd/yyy hh:mm tt")) to $($t5_end_time.ToString("hh:mm tt"))"

    #Canberra, Melbourne, Sydney
    $t6= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "AUS Eastern Standard Time" }
    $t6_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t6)
    $t6_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t6)
    $time6="$($t6_time_start.ToString("MM/dd/yyy hh:mm tt")) to $($t6_end_time.ToString("hh:mm tt"))"

    $Start_time = $fromtime
    $End_time = $totime

    $list_of_timezone = [System.TimeZoneInfo]::GetSystemTimeZones( ) |Sort-Object DisplayName
    
    $overall_result = @();
    $count = 1  
    foreach ($timezone in $list_of_timezone) {
    $converted_time_start = [System.TimeZoneInfo]::ConvertTime( $Start_time, $fromtzone, $timezone)
    $converted_end_time = [System.TimeZoneInfo]::ConvertTime( $End_time, $fromtzone, $timezone)
 
    $obj = [pscustomobject][ordered] @{ 
    Sl_No = $count
    Time_zone_Name = $timezone.DisplayName
    #coverted_time_start = $converted_time_start.tostring('yyyy-MM-dd hh:mm:ss tt')
    Maintenance_Start_Time = $converted_time_start.tostring('dd-MMM-yyyy hh:mm:ss tt')
    Maintenance_End_Time= $converted_end_time.tostring('dd-MMM-yyyy hh:mm:ss tt')
    }
    $count +=1
    $overall_result +=$obj
    #break
    }

$Header = @"
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;padding: 4px}
TH {border-width: 1px; padding: 10px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 10px; border-style: solid; border-color: black;}
tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
"@

    $who = $who -replace "/" , "_"
    $who = $who -replace "\\", "_"
    $who = $who -replace ":",""

    $log = "$path\timezone_attachment\DifferentTimeZones_$who_$logdate.html"
    $overall_result| ConvertTo-Html -Property * -Head $Header | Out-File -FilePath $log

#$content=Get-Content "$path\mail_content.txt"
$htmlnew='<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-micros
oft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40">
<head>

<meta name="Generator" content="Microsoft Word 15 (filtered medium)">
<!--[if !mso]>
<style>
v\:* {behavior:url(#default#VML);
}
o\:* {behavior:url(#default#VML);}
w\:* {behavior:url(#default#VML);}
.shape {behavior:url(#default#VML);}
</style>
<![endif]-->
<style>
<!--
/* Font Definitions */
@font-face
  {font-family:"Cambria Math";
  panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
  {font-family:Calibri;
  panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
  {font-family:"Segoe UI";
  panose-1:2 11 5 2 4 2 4 2 2 3;}
@font-face
  {font-family:inherit;
  panose-1:0 0 0 0 0 0 0 0 0 0;}
/* Style Definitions */
p.MsoNormal, li.MsoNormal, div.MsoNormal
  {margin:0in;
  margin-bottom:.0001pt;
  font-size:11.0pt;
  font-family:"Calibri",sans-serif;}
a:link, span.MsoHyperlink
  {mso-style-priority:99;
  color:#0563C1;
  text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
  {mso-style-priority:99;
  color:#954F72;
  text-decoration:underline;}
p
  {mso-style-priority:99;
  mso-margin-top-alt:auto;
  margin-right:0in;
  mso-margin-bottom-alt:auto;
  margin-left:0in;
  font-size:12.0pt;
  font-family:"Times New Roman",serif;}
span.EmailStyle17
  {mso-style-type:personal-compose;
  font-family:"Calibri",sans-serif;
  color:windowtext;}
.MsoChpDefault
  {mso-style-type:export-only;
  font-family:"Calibri",sans-serif;}
@page WordSection1
  {size:8.5in 11.0in;
  margin:1.0in 1.0in 1.0in 1.0in;}
div.WordSection1
  {page:WordSection1;}
-->
</style>
<!--[if gte mso 9]>
<xml>

<o:shapedefaults v:ext="edit" spidmax="1026" />

</xml>
<![endif]-->
<!--[if gte mso 9]>
<xml>

<o:shapelayout v:ext="edit">

<o:idmap v:ext="edit" data="1" />

</o:shapelayout>
</xml>
<![endif]-->

</head>

<body lang="EN-US" link="#0563C1" vlink="#954F72" style="background-color:#A9A9A9;">

<div class="WordSection1">


<span style="font-size:12.0pt">
<o:p></o:p>
</span>
</p>

<p class="MsoNormal">
<o:p>&nbsp;</o:p>
</p>

<table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0"  style="background:#BBC0C5;border-collapse:collapse;margin-left:auto;margin-right:auto">
    <tr>
        <td style="padding:0in 0in 0in 0in">
            <div align="center">
                <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;border-collapse:collapse">
                    <tr>
                       <td style="padding:0in 0in 0in 0in">
                            <div align="center">
                                <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;background:white;border-collapse:collapse">
                                    <tr>
                                        <td style="padding:7.5pt 0in 7.5pt 0in">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                            <tr>
                                            <td width="325" valign="top" style="width:243.75pt;padding:0in 0in 0in 0in">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:243.5pt;border-collapse:collapse">
                                            <tr>
                                            <td valign="top" style="padding:0in 11.25pt 0in 11.25pt">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:221.0pt;border-collapse:collapse">
                                            <tr>
                                            <td style="padding:11.25pt 11.25pt 11.25pt 11.25pt">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                            <tr>
                                            <td width="200" style="width:150.0pt;padding:0in 0in 0in 0in">
                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <a href="https://blueyonder.com" target="_blank">
                                            <span style="font-size:11.0pt;color:blue;border:none windowtext 1.0pt;padding:0in;text-decoration:none">
                                            <img border="0" width="200" height="53" style="width:2.0833in;height:.5486in" id="Picture_x0020_14" src="cid:Attachment" alt="BlueYonder logo">
                                            </span>
                                            </a>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;"><o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            <td width="325" valign="top" style="width:243.75pt;padding:0in 0in 0in 0in;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:244.0pt;border-collapse:collapse;word-break:break-word">
                                            <tr>
                                            <td valign="top" style="padding:0in 11.25pt 0in 11.25pt;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:221.5pt;border-collapse:collapse;word-break:break-word">
                                            <tr>
                                            <td style="padding:18.75pt 15.0pt 7.5pt 18.75pt;word-break:break-word">
                                            <div align="right">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;word-break:break-word">
                                            <tr style="height:26.25pt">
                                            <td valign="top" style="padding:0in 0in 0in 0in;height:26.25pt;word-break:break-word">
                                            <p align="right" style="margin:0in;margin-bottom:.0001pt;text-align:right;line-height:22.5pt;vertical-align:baseline;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.6pt;color:black;border:none windowtext 1.0pt;padding:0in">BlueYonder Maintenance Notification
                                            </span>
                                            </b>
                                            </p>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            <tr id="x_header_image_module">
                                            <td style="padding:0in 0in 0in 0in">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;border-spacing: 0px">
                                            <tr style="border-spacing: 0px">
                                            <td width="650" style="width:487.5pt;padding:0in 0in 0in 0in">
                                            <p style="margin:0in;margin-bottom:.0001pt;vertical-align:baseline;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <img border="0" width="650" height="170" style="width:6.7708in;height:1.7708in" id="Picture_x0020_13" src="cid:Attachment1">
                                            </span>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            <tr id="x_level_one_heading9d98794d-c329-40f9-90d1-c53cc20ce518">
                                            <td style="padding:0in 0in 0in 0in;word-break:break-word">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td style="padding:0in 0in 0in 0in;word-break:break-word">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;background:white;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td style="padding:22.5pt 0in 7.5pt 0in;word-break:break-word">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td width="650" valign="top" style="width:487.5pt;padding:0in 0in 0in 0in;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td valign="top" style="padding:0in 11.25pt 0in 11.25pt;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:465.0pt;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td style="padding:0in 15.0pt 0in 15.0pt;word-break:break-word">
                                            <p align="center" style="margin:0in;margin-bottom:.0001pt;text-align:center;line-height:37.5pt;vertical-align:baseline;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:22.0pt;color:#28B6E9;border:none windowtext 1.0pt;padding:0in">
                                            Monthly Maintenance</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            <tr id="x_primary_text">
                                            <td style="padding:0in 0in 0in 0in;word-break:break-word">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td style="padding:0in 0in 0in 0in;word-break:break-word">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;background:white;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td style="padding:11.25pt 0in 11.25pt 0in;word-break:break-word">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td width="650" valign="top" style="width:487.5pt;padding:0in 0in 0in 0in;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td valign="top" style="padding:0in 11.25pt 0in 11.25pt;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:465.0pt;border-collapse:collapse;word-break:break-word">
                                            <tr style="word-break:break-word">
                                            <td style="padding:0in 15.0pt 0in 15.0pt;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:431.0pt;border-collapse:collapse;word-break:break-word">
                                            <tr style="height:19.4pt;word-break:break-word">
                                            <td width="136" valign="top" style="width:96.2pt;border:solid windowtext 1.0pt;background:#00B0F0;padding:0in 5.4pt 0in 5.4pt;height:19.4pt;word-break:break-word">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">
                                            Customer Name</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            <td width="439" colspan="2" valign="top" style="width:310.2pt;border:solid windowtext 1.0pt;border-left:none;background:#00B0F0;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:black;border:none windowtext 1.0pt;padding:0in">
                                            '+$who+'</span>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr style="height:19.4pt">
                                            <td width="136" valign="top" style="width:96.2pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">
                                            Systems</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            <td width="439" colspan="2" valign="top" style="width:310.2pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            '+$sys+'<o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr style="height:19.4pt">
                                            <td width="136" valign="top" style="width:96.2pt;border:solid windowtext 1.0pt;border-top:none;background:#00B0F0;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">
                                            URL</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            <td width="439" colspan="3" valign="top" style="width:310.2pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:#00B0F0;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:black;border:none windowtext 1.0pt;padding:0in">
                                            '+$urlss+'</span>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr style="height:83.95pt">
                                            <td width="136" valign="top" style="width:96.2pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:83.95pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">
                                            Impact</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            <td width="439" colspan="2" valign="top" style="width:310.2pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:83.95pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">BlueYonder Cloud Services will be performing maintenance activity on the Server Infrastructure. </br></br>
During the maintenance window, the environment will be unavailable for use. </br></br>
A notification email will be sent prior to the start of the maintenance and upon successful completion of the maintenance activity. 
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr style="height:19.4pt">
                                            <td width="136" rowspan="3" style="width:96.2pt;border:solid windowtext 1.0pt;border-top:none;background:#00B0F0;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">
                                            Maintenance Window</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            <td  width="177" valign="top" style="width:116pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:#00B0F0;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p align="center" style="margin:0in;margin-bottom:.0001pt;text-align:center;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">Start</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            <td width="182" valign="top" style="width:116pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;background:#00B0F0;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p align="center" style="margin:0in;margin-bottom:.0001pt;text-align:center;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">
                                            End</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr style="height:19.4pt">
                                            <td width="257"  valign="top" style="width:116pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">'+$fromtime+'<o:p></o:p></span>
                                            </p>
                                            </td>
                                            <td width="182" valign="top" style="width:116pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">'+$totime+'<o:p></o:p></span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr style="height:19.4pt">
                                            <td width="257" valign="top" style="width:116pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">'+$fromtzone.Id+'<o:p></o:p></span>
                                            </p>
                                            </td>
                                            <td width="182" valign="top" style="width:116pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:19.4pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">'+$fromtzone.Id+'<o:p></o:p></span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr style="height:83.95pt">
                                            <td width="136" valign="top" style="width:96.2pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:83.95pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">
                                            Additional Timezone</span>
                                            </b>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            <td width="439" colspan="2" valign="top" style="width:310.2pt;border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:83.95pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:10.1pt;font-family:Calibri,sans-serif;
">
                        '+$time1+' Coordinated Universal Time</br>
                        '+$time2+' Dublin, Edinburgh, Lisbon, London </br>
                        '+$time3+' Brussels, Copenhagen, Madrid, Paris</br>
                        '+$time4+' Indian Standard Time </br>
                        '+$time5+' Osaka, Sapporo, Tokyo</br>
                        '+$time6+' Canberra, Melbourne, Sydney </br>
                        <p style="color: blue;"><i>Please refer the attachment for additional Time zones.</i></p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            </table>
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#2F5496;border:none windowtext 1.0pt;padding:0in">
                                            &nbsp;</span>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <b><span style="font-size:11.0pt;font-family:Calibri,sans-serif;
;color:#444444;border:none windowtext 1.0pt;padding:0in">Further questions -</span>
                                            </b><span style="font-size:10.0pt;border:none windowtext 1.0pt;padding:0in">&nbsp;</span><span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">Please contact your Technical Account Manager or create a support case by reaching out to <b>Server Support Team</b> at <b>1-214-294-1126</b>
                                            </p>
                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:7.0pt;font-family:&quot;inherit&quot;,serif;border:none windowtext 1.0pt;padding:0in">
                                            &nbsp;</span>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>

                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            <tr>
                                            <td style="padding:0in 0in 0in 0in">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:487.5pt;background:#E6E7E8;border-collapse:collapse">
                                            <tr>
                                            <td style="padding:22.5pt 0in 15.0pt 0in">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                            <tr>
                                            <td width="390" valign="top" style="width:292.5pt;padding:0in 0in 0in 0in">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:292.5pt;border-collapse:collapse">
                                            <tr>
                                            <td valign="top" style="padding:0in 11.25pt 0in 11.25pt">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:3.75in;border-collapse:collapse">
                                            <tr>
                                            <td style="padding:7.5pt 18.75pt 3.75pt 18.75pt">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <a href="https://blueyonder.com/privacy-policy" target="_blank">
                                            <b>
                                            <span style="font-size:10.0pt;font-family:&quot;Times New Roman&quot;,serif;color:#333333;border:none windowtext 1.0pt;padding:0in">
                                            Privacy Policy</span>
                                            </b>
                                            </a>
                                            </span>
                                            <strong>
                                            <span style="font-size:10.0pt;color:#333333;border:none windowtext 1.0pt;padding:0in">,&nbsp;</span>
                                            </strong>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <a href=https://blueyonder.com/terms-of-use" target="_blank">
                                            <b>
                                            <span style="font-size:10.0pt;font-family:&quot;Times New Roman&quot;,serif;color:#333333;border:none windowtext 1.0pt;padding:0in">
                                            Terms of Use</span>
                                            </b>
                                            </a>
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            <tr>
                                            <td style="padding:3.75pt 18.75pt 7.5pt 18.75pt;word-break:break-word">
                                            <p style="margin:0in;margin-bottom:.0001pt;line-height:10.5pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                            <span style="font-size:10.0pt;color:#333333;border:none windowtext 1.0pt;padding:0in">
                                            Copyright &copy; 2020 Blue Yonder Group, Inc.<br>
                                            All rights reserved.</span>
                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
">
                                            <o:p></o:p>
                                            </span>
                                            </p>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            <td width="260" valign="top" style="width:195.0pt;padding:0in 0in 0in 0in;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:195.0pt;border-collapse:collapse;word-break:break-word">
                                            <tr>
                                            <td valign="top" style="padding:0in 11.25pt 0in 11.25pt;word-break:break-word">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="0" style="width:172.5pt;border-collapse:collapse;word-break:break-word">
                                            <tr>
                                            <td style="padding:7.5pt 18.75pt 7.5pt 18.75pt;word-break:break-word">
                                            <div align="center">
                                            <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse;word-break:break-word">
                                                <tr>
                                                    <td width="180" style="width:135.0pt;padding:0in 0in 0in 0in;word-break:break-word">
                                                        <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                                        <span style="font-size:11.0pt;border:none windowtext 1.0pt;padding:0in">
                                                        <img border="0" width="180" height="37" style="width:1.875in;height:.3819in" id="Picture_x0020_8" src="cid:Attachment6" alt="Blue Yonder">
                                                        </span>
                                                        <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p></span>
                                                        </p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                <td width="180" style="width:135.0pt;padding:0in 0in 0in 0in">
                                                <div align="center">
                                                    <table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" style="border-collapse:collapse">
                                                    <tr>
                                                        <td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
                                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                                                <a href="https://blog.blueyonder.com/" target="_blank">
                                                                <span style="font-size:11.0pt;color:blue;border:none windowtext 1.0pt;padding:0in;text-decoration:none">
                                                                <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_7" src="cid:Attachment7" alt="Blue Yonder Blog - Fulfill your potential">
                                                                </span>
                                                                </a>
                                                                <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p></span>
                                                            </p>
                                                        </td>
                                                        <td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
                                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                                                <a href="https://www.linkedin.com/company/blueyonderai/" target="_blank">
                                                                <span style="font-size:11.0pt;color:blue;border:none windowtext 1.0pt;padding:0in;text-decoration:none">
                                                                <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_6" src="cid:Attachment8" alt="LinkedIn">
                                                                </span>
                                                                </a>
                                                                <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p></span>
                                                            </p>
                                                        </td>
                                                        <td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
                                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                                                <a href="https://www.instagram.com/blueyonder__ai/" target="_blank">
                                                                <span style="font-size:11.0pt;color:blue;border:none windowtext 1.0pt;padding:0in;text-decoration:none">
                                                                <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_5" src="cid:Attachment9" alt="Instagram">
                                                                </span>
                                                                </a>
                                                                <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p></span>
                                                            </p>
                                                        </td>
                                                        <td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
                                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                                                <a href="https://twitter.com/BlueYonder" target="_blank">
                                                                <span style="font-size:11.0pt;color:blue;border:none windowtext 1.0pt;padding:0in;text-decoration:none">
                                                                <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_4" src="cid:Attachment10" alt="Twitter">
                                                                </span>
                                                                </a>
                                                                <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p></span>
                                                            </p>
                                                        </td>
                                                        <td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
                                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                                                <a href="https://www.facebook.com/BlueYonderAI/" target="_blank">
                                                                <span style="font-size:11.0pt;color:blue;border:none windowtext 1.0pt;padding:0in;text-decoration:none">
                                                                <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_3" src="cid:Attachment11" alt="Facebook">
                                                                </span>
                                                                </a>
                                                            <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p></span>
                                                            </p>
                                                        </td>
                                                        <td style="padding:3.0pt 3.0pt 3.0pt 3.0pt">
                                                            <p style="margin:0in;margin-bottom:.0001pt;mso-element:frame;mso-element-frame-hspace:9.0pt;mso-element-wrap:around;mso-element-anchor-vertical:paragraph;mso-element-anchor-horizontal:column;mso-element-top:.05pt;mso-height-rule:exactly">
                                                                <a href="https://www.youtube.com/c/BlueYonderAI" target="_blank">
                                                                    <span style="font-size:11.0pt;color:blue;border:none windowtext 1.0pt;padding:0in;text-decoration:none">
                                                                    <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_2" src="cid:Attachment12" alt="YouTube">
                                                                    </span>
                                                                </a>
                                                                <span style="font-size:11.0pt;font-family:Calibri,sans-serif;
"><o:p></o:p></span>
                                                            </p>
                                                        </td>
                                                    </tr>
                                                    </table>
                                                </div>
                                                </td>
                                                </tr>
                                            </table>
                                            </div>
                                            </td>
                                            </tr>
                                            </table>
                                            </td>
                                            </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </td>
    </tr>
</table>
<p class="MsoNormal">
<br clear="all">
<o:p></o:p>
</p>
</div>
</body>
</html>'
#[string]::Format("$content", ($who,$sys,$urlss,$fromtime,$totime,$fromtzone.Id,$time1,$time2,$time3,$time4,$time5,$time6))
$to=$cus.email_to
$cc=$cus.email_cc
$bcc=$cus.email_bcc
$fm="test@jdadelivers.com"
        $SMTPMessage = New-Object System.Net.Mail.MailMessage
        $SMTPServer = "mailout.jdadelivers.com"
        if($to)
        {
        $to=($to -replace ",",";") -split ";"
            foreach($t in $to)
            {
                $SMTPMessage.To.Add($t)
            }
        }
        
        if($cc)
        {
        $cc=($cc -replace ",",";") -split ";"
            foreach($c in $cc)
            {
                $SMTPMessage.CC.Add($c)
            }
        }

        if($bcc)
        {
        $bcc=($bcc -replace ",",";") -split ";"
            foreach($b in $bcc)
            {
                $SMTPMessage.Bcc.Add($bcc)
            }
        }
        
        $SMTPMessage.from=$fm

        $SMTPMessage.subject = "Monthly Maintenance _ Gentle Reminder - 5 day  $who"
        
        $SMTPMessage.IsBodyHTML = $true
        $SMTPClient = New-Object Net.Mail.SmtpClient($SmtpServer, 25)
        $SMTPClient.UseDefaultCredentials = $False
        $imgpath="$path\images"
        $image="$imgpath\image0000.png"
        $image1="$imgpath\image0001.png"
        $image6="$imgpath\image0006.png"
        $image7="$imgpath\image0007.png"
        $image8="$imgpath\image0008.png"
        $image9="$imgpath\image0009.png"
        $image10="$imgpath\image0010.png"
        $image11="$imgpath\image0011.png"
        $image12="$imgpath\image0012.png"

        
        $messageBody = [Net.Mail.AlternateView]::CreateAlternateViewFromString($htmlnew, 'text/html')
        # Create a Linked Resource from the logo image
        $imageMimeType = New-Object System.Net.Mime.ContentType("image/png")

        $embeddedImage = New-Object Net.Mail.LinkedResource("$image", $imageMimeType)
        $embeddedImage.ContentId = "Attachment"
        $messageBody.LinkedResources.Add($embeddedImage)
        
        $embeddedImage1 = New-Object Net.Mail.LinkedResource("$image1", $imageMimeType)
        $embeddedImage1.ContentId = "Attachment1"
        $messageBody.LinkedResources.Add($embeddedImage1)

        $embeddedImage6 = New-Object Net.Mail.LinkedResource("$image6", $imageMimeType)
        $embeddedImage6.ContentId = "Attachment6"
        $messageBody.LinkedResources.Add($embeddedImage6)

        $embeddedImage7 = New-Object Net.Mail.LinkedResource("$image7", $imageMimeType)
        $embeddedImage7.ContentId = "Attachment7"
        $messageBody.LinkedResources.Add($embeddedImage7)

        $embeddedImage8 = New-Object Net.Mail.LinkedResource("$image8", $imageMimeType)
        $embeddedImage8.ContentId = "Attachment8"
        $messageBody.LinkedResources.Add($embeddedImage8)

        $embeddedImage9 = New-Object Net.Mail.LinkedResource("$image9", $imageMimeType)
        $embeddedImage9.ContentId = "Attachment9"
        $messageBody.LinkedResources.Add($embeddedImage9)

        $embeddedImage10 = New-Object Net.Mail.LinkedResource("$image10", $imageMimeType)
        $embeddedImage10.ContentId = "Attachment10"
        $messageBody.LinkedResources.Add($embeddedImage10)

        $embeddedImage11 = New-Object Net.Mail.LinkedResource("$image11", $imageMimeType)
        $embeddedImage11.ContentId = "Attachment11"
        $messageBody.LinkedResources.Add($embeddedImage11)

        $embeddedImage12 = New-Object Net.Mail.LinkedResource("$image12", $imageMimeType)
        $embeddedImage12.ContentId = "Attachment12"
        $messageBody.LinkedResources.Add($embeddedImage12)

        $SMTPMessage.AlternateViews.Add($messageBody) #body
        $SMTPMessage.Attachments.Add($log)
        $SMTPClient.Send($SMTPMessage)

    }
}


