﻿function patching_dates($count,$Year){    
$output = @()    
$FindNthDay= 2 
$WeekDay= "Tuesday" 
$months = @(1,2,3,4,5,6,7,8,9,10,11,12)    
#$Year="2021"
foreach($month in $months){         
[datetime]$StrtMonth=$month.ToString()+'/1/'+$Year   
while ($StrtMonth.DayofWeek -ine $WeekDay ) { $StrtMonth=$StrtMonth.AddDays(1) }    
$output += $StrtMonth.AddDays(7*($FindNthDay-1)+$count)    }    
return $output
} 
$month_ns=(New-Object System.Globalization.DateTimeFormatInfo).MonthNames

$overall=@()

$FindNthDay= 2 
$WeekDay= "Tuesday" 
#$d1='3/20/2021'
#$d2='4/24/2021'
#$date1='20'
#$date2='24'
#$M1='March'
#$M2='April'

#$d1='3/20/2021'
#$d2='4/20/2021'
#$date1='20'
#$date2='20'
#$M1='March'
#$M2='April'

#$d1='3/1/2021'
#$d2='4/1/2021'
#$date1='1'
#$date2='1'
#$M1='February'
#$M2='March'

$d1='3/3/2021'
$d2='3/31/2021'
$date1='3'
$date2='31'
$M1='February'
$M2='March'

$Y1='2021'
$Y2='2021'


$newyear='2021'
$cusid='101'
$eid='2'


if($d1 -and $d2)
{
    [datetime]$StrtMonth="$M1/1/$Y1"
    while($StrtMonth.DayofWeek -ine $WeekDay ) 
    { $StrtMonth=$StrtMonth.AddDays(1) }
    $sT_nM=$StrtMonth.AddDays(7*($FindNthDay-1))
    $d1_ct=(NEW-TIMESPAN –Start $sT_nM –End $d1).Days
    
    [datetime]$StrtMonth="$M2/1/$Y2"
    while($StrtMonth.DayofWeek -ine $WeekDay ) 
    { $StrtMonth=$StrtMonth.AddDays(1) }
    $sT_dM=$StrtMonth.AddDays(7*($FindNthDay-1))
    $d2_ct=(NEW-TIMESPAN –Start $sT_dM –End $d2).Days
    
    if($d1_ct -eq $d2_ct)
    {
        $dates=patching_dates -count $d1_ct -Year $newyear
        $result=@()
        $i=0
        foreach($dt in $dates)
        {
          $result+= [PSCustomObject]@{
          'Customer_ID'=$cusid
          'E_ID'=$eid
          'Year'=$newyear
          'Month'=$month_ns[$i]
          'Day_Date'=Get-Date $dt -Format "dd"
          'S_ID'=''
          'Patch_Date'=Get-Date $dt -Format "MM/dd/yyy"
          'state'='new'
          }
        $i++
        }
        $overall+=$result
    }
    else
    {
        if($date1 -eq $date2)
        {
            if((Get-Date $([datetime]$d1) -Format "MMMM") -eq $M1)
            {
                $months = @(1,2,3,4,5,6,7,8,9,10,11,12)    
                $result=@()
                foreach($month in $months)
                {
                    [datetime]$StrtMonth=$month.ToString()+'/'+$date1+'/'+$newyear
                    $result+= [PSCustomObject]@{
                      'Customer_ID'=$cusid
                      'E_ID'=$eid
                      'Year'=$newyear
                      'Month'=Get-Date -Month $month -Format MMMM
                      'Day_Date'=Get-Date $StrtMonth -Format "dd"
                      'S_ID'=''
                      'Patch_Date'=Get-Date $StrtMonth -Format "MM/dd/yyy"
                      'state'='new'
                      }
                }
                $overall+=$result
            }
            else
            {
                $months=(New-Object System.Globalization.DateTimeFormatInfo).MonthNames
                $month_no=([array]::indexof($months,$M1)+1)+1   ##+1 for index +1 for next month
                $nxt_month="$month_no/$date1/$Y1"
                if($d1 -eq $nxt_month)
                {
                   $months = @(1,2,3,4,5,6,7,8,9,10,11,12)    
                   $result=@()
                   #$Year="2021"
                   foreach($month in $months)
                   {
                    $month+=1
                    if($month -eq 13){$month=1;$newyear=[int]$newyear+1}
                       [datetime]$StrtMonth=$month.ToString()+'/'+$date1+'/'+$newyear
                       $result+= [PSCustomObject]@{
                         'Customer_ID'=$cusid
                         'E_ID'=$eid
                         'Year'=$newyear
                         'Month'=Get-Date -Month $month -Format MMMM
                         'Day_Date'=Get-Date $StrtMonth -Format "dd"
                         'S_ID'=''
                         'Patch_Date'=Get-Date $StrtMonth -Format "MM/dd/yyy"
                         'state'='new'
                         }
                   }
                   $overall+=$result
                }
                else
                {
                Write-Host "Unable to find format $cusid"
                $error_data= [PSCustomObject]@{
                         'Customer_ID'=$cusid
                         'Error'="Unable to find format $cusid"
                         }
                }
            }
            
        }
        else
        {
        Write-Host "Date formats doesn't match $cusid"
        $error_data= [PSCustomObject]@{
                 'Customer_ID'=$cusid
                 'Error'="Date formats doesn't match $cusid"
                 }
        }
    }
}
else
{
Write-Host "d1 or d2 is empty" -ForegroundColor Red
$error_data+= [PSCustomObject]@{
     'Customer_ID'=$cusid
     'Error'="d1 or d2 is empty $cusid"
     }
}

$overall|ft