﻿$path="."
$logdate = (get-date).ToString("dd-MMM-yyyy_hhmmss")
function Get-tz($tz)
{
    if($tz -eq "EST" -or $tz -eq "EDT")
    {
        $zone=[System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Eastern Standard Time" }
    }
    elseif($tz -eq "JST")
    {
        $zone=[System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Tokyo Standard Time"}
    }
    elseif($tz -eq "IST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "India Standard Time"}
    }
    elseif ($tz -eq "CES")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central Europe Standard Time"}
    }
    elseif ($tz -eq "CET")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central Europe Standard Time"}
    }
    elseif ($tz -eq "CST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central Standard Time"}
    }
    elseif ($tz -eq "AES")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "AUS Eastern Standard Time"}
    }
    elseif ($tz -eq "UTC")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "UTC"}
    }
    elseif ($tz -eq "GMT")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "GMT Standard Time"}
    }
    elseif ($tz -eq "BST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Central European Standard Time"}
    }
    elseif ($tz -eq "PST")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Pacific Standard Time"}
    }
    elseif ($tz -eq "SGT")
    {
        $zone = [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Singapore Standard Time"}
    }
    elseif ($tz -eq "brisbane")
    {
        $zone=[System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "E. Australia Standard Time"}
    }
    return $zone
}

Function Run-MySQLQuery  {

	Param(
        [Parameter(
            Mandatory = $true,
            ParameterSetName = '',
            ValueFromPipeline = $true)]
            [string]$query,   
		[Parameter(
            Mandatory = $true,
            ParameterSetName = '',
            ValueFromPipeline = $true)]
            [string]$connectionString          
        )
	Begin {
		#Write-Verbose "Starting Begin Section"		
    }
	Process {
		#Write-Verbose "Starting Process Section"
		try {
			# load MySQL driver and create connection
			Write-Verbose "Create Database Connection"
			# You could also could use a direct Link to the DLL File
			 $mySQLDataDLL = "C:\Program Files (x86)\MySQL\MySQL Connector Net 8.0.22\Assemblies\v4.5.2\MySql.Data.dll"
			 [void][system.reflection.Assembly]::LoadFrom($mySQLDataDLL)
			#[void][System.Reflection.Assembly]::LoadWithPartialName("MySql.Data") | Out-Null
			$connection = New-Object MySql.Data.MySqlClient.MySqlConnection
			$connection.ConnectionString = $ConnectionString
			#Write-Verbose "Open Database Connection"
			$connection.Open()			
			# Run MySQL Querys
			#Write-Verbose "Run MySQL Querys"
			$command = New-Object MySql.Data.MySqlClient.MySqlCommand($query, $connection)
			$dataAdapter = New-Object MySql.Data.MySqlClient.MySqlDataAdapter($command)
			$dataSet = New-Object System.Data.DataSet
			$recordCount = $dataAdapter.Fill($dataSet, "data")
			#$dataSet.Tables["data"] | Format-Table
            return $dataSet.Tables["data"]
		}	
	
		catch {
			#Write-Host "Could not run MySQL Query" $Error[0]	
		}	
		Finally {
			#Write-Verbose "Close Connection"
			$connection.Close()
		}
        }
	End {
		#Write-Verbose "Starting End Section"
	}
}
$ConnectionString = "Server=127.0.0.1;Uid=root;Pwd='';database=compliance_report;"
$5_day="SELECT Distinct customer_info.customer_name, customer_info.customer_maintance, customer_info.email_to, customer_info.email_cc, customer_info.email_bcc, customer_info.email_content, customer_info.system_service_affected, customer_info.status, customer_info.url, patch_info_new.patch_date, 
        (CASE 
        WHEN customer_info.e_id = '1' THEN 'Prod' 
        WHEN customer_info.e_id = '2' THEN 'Non-Prod' 
        END) AS env 
        FROM customer_info 
        inner join patch_info_new on customer_info.customer_name = patch_info_new.customer_name and customer_info.e_id=patch_info_new.e_id 
        WHERE (DATEDIFF( patch_info_new.patch_date,CONVERT(now(),date)) = 5)"
$5data=@()
#$5data = Run-MySQLQuery -query $5_day -connectionString $ConnectionString
$5_data=Import-Csv "$path\test.csv"
if($5data)
{
$symbol=[char]0x00A9
    foreach($cus in $5_data)
    {
    $time=$cus.customer_maintance
    $date=$cus.patch_date
    $who=$cus.customer_name
    $sys=$cus.system_service_affected
    $urls=$cus.url
    $urlss=""

    if($urls)
    {
    $urls=$urls -replace ",",";"
    $urls=($urls -split ";")
    $count=1
    $tcount=$urls.count
        foreach($url in $urls)
        {
            if($count -eq $tcount)
            {
                $urlss+="<a>$url</a>"
            }
            else
            {
                $urlss+="<a>$url</a></br>"
            }
            $count++
        }
    }
    else
    {$urlss+="<p>&nbsp;</p>"}


    $from=$time -split " "
    $fromhr=[int]($from[0] -split ":")[0]
    $frommin=($from[0] -split ":")[1]
    $fromampm = $from[1]
    if ($fromampm -eq "AM")
    {
        if ($fromhr -eq 12)
        {
            $fromhr = 0
        }
    }
    elseif ($fromampm -eq "PM")
    {
        if ($fromhr -eq 12)
        {
            $fromhr=12
        }
        else
        {
            $fromhr += 12;
        }
    }

    if($fromampm -eq "PM" -and $toampm -eq "AM")
    {
        $todate=get-date ((Get-date $date).AddDays(1)) -Format "MM/dd/yyy"
    }
    else
    
    {
        $todate=get-date $date -Format "MM/dd/yyy"
    }

    $tohr=[int]($from[4] -split ":")[0]
    $tomin=[int]($from[4] -split ":")[1]
    $toampm=$from[5]
    if ($toampm -eq "AM")
    {
        if ($tohr -eq 12)
        {
            $tohr = 0
        }
    }
    elseif ($toampm -eq "PM")
    {
        if ($tohr -eq 12)
        {
            $tohr=12
        }
        else
        {
            $tohr += 12;
        }
    }
    $fromtime=Get-Date -Date $date -Hour "$fromhr" -Minute $frommin
    $totime=Get-Date -Date $todate -Hour "$tohr" -Minute $tomin

    $tz=$from[2]

    $fromtzone=Get-tz -tz $tz

    #Coordinated Universal Time
    $t1= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "UTC" }
    $t1_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t1)
    $t1_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t1)
    $time1="$($t1_time_start.ToString("dd-MMM-yyyy hh:mm tt")) to $($t1_end_time.ToString("hh:mm tt"))"

    #Dublin, Edinburgh, Lisbon, London
    $t2= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "GMT Standard Time" }
    $t2_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t2)
    $t2_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t2)
    $time2="$($t2_time_start.ToString("dd-MMM-yyyy hh:mm tt")) to $($t2_end_time.ToString("hh:mm tt"))"

    #Brussels, Copenhagen, Madrid, Paris
    $t3= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "Romance Standard Time" }
    $t3_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t3)
    $t3_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t3)
    $time3="$($t3_time_start.ToString("dd-MMM-yyyy hh:mm tt")) to $($t3_end_time.ToString("hh:mm tt"))"

    #Indian Standard Time
    $t4= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -match "India Standard Time" }
    $t4_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t4)
    $t4_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t4)
    $time4="$($t4_time_start.ToString("dd-MMM-yyyy hh:mm tt")) to $($t4_end_time.ToString("hh:mm tt"))"

    #Tokyo Standard Time
    $t5= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "Tokyo Standard Time" }
    $t5_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t5)
    $t5_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t5)
    $time5="$($t5_time_start.ToString("dd-MMM-yyyy hh:mm tt")) to $($t5_end_time.ToString("hh:mm tt"))"

    #Canberra, Melbourne, Sydney
    $t6= [System.TimeZoneInfo]::GetSystemTimeZones() | Where-Object { $_.Id -eq "AUS Eastern Standard Time" }
    $t6_time_start = [System.TimeZoneInfo]::ConvertTime( $fromtime, $fromtzone, $t6)
    $t6_end_time = [System.TimeZoneInfo]::ConvertTime( $totime, $fromtzone, $t6)
    $time6="$($t6_time_start.ToString("dd-MMM-yyyy hh:mm tt")) to $($t6_end_time.ToString("hh:mm tt"))"

    $Start_time = $fromtime
    $End_time = $totime

    $list_of_timezone = [System.TimeZoneInfo]::GetSystemTimeZones( ) |Sort-Object DisplayName
    
    $overall_result = @();
    $count = 1  
    foreach ($timezone in $list_of_timezone) {
    $converted_time_start = [System.TimeZoneInfo]::ConvertTime( $Start_time, $fromtzone, $timezone)
    $converted_end_time = [System.TimeZoneInfo]::ConvertTime( $End_time, $fromtzone, $timezone)
 
    $obj = [pscustomobject][ordered] @{ 
    Sl_No = $count
    Time_zone_Name = $timezone.DisplayName
    #coverted_time_start = $converted_time_start.tostring('yyyy-MM-dd hh:mm:ss tt')
    Maintenance_Start_Time = $converted_time_start.tostring('dd-MMM-yyyy hh:mm:ss tt')
    Maintenance_End_Time= $converted_end_time.tostring('dd-MMM-yyyy hh:mm:ss tt')
    }
    $count +=1
    $overall_result +=$obj
    #break
    }

$Header = @"
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;padding: 4px}
TH {border-width: 1px; padding: 10px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 10px; border-style: solid; border-color: black;}
tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
"@

    $who = $who -replace "/" , "_"
    $who = $who -replace "\\", "_"
    $who = $who -replace ":",""

    $log = "$path\DifferentTimeZones_$who_$logdate.html"
    $overall_result| ConvertTo-Html -Property * -Head $Header | Out-File -FilePath $log


$htmlnew='<!DOCTYPE html>
<html>
<head></head>
<body>
<style>
table {
  border-collapse: collapse;
} 
th,td {
  padding: 1.5px;
}
th{
    text-align: left;
    background-color: #00B0F0;
}
table.a{
  border-collapse: collapse;
  border: 1pt solid black;
}
th,td.a{
  border: 1px solid black;
}
}
</style>
<table  style="table-layout: fixed;">
    <col width="2.0in" >
    <col width="5.0in">
    <tr>
        <td>
            <img border="0" width="200" height="53" style="width:2.0833in;height:.5486in" id="Picture_x0020_14" src="cid:Attachment" alt="BlueYonder logo">
        </td>
        <td style="text-align:right">
            <p style="vertical-align:baseline;">
                <b>BlueYonder Maintenance Notification</b><span>&nbsp;  </span>
            </p>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <img border="0" width="700" height="170" style="width:8.000in;height:1.7708in" id="Picture_x0020_13" src="cid:Attachment1">
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <p align="center" style="margin:0in;margin-bottom:.0001pt;text-align:center;line-height:37.5pt;vertical-align:baseline;">
            <b><span style="font-size:22.0pt;color:#28B6E9;">Monthly Maintenance</span></b>
            </p>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table style="table-layout: fixed;" class="a">
            <col width="2.0in" >
            <col width="5.0in">
                <tr>
                    <th>
                        Customer Name
                    </th>
                    <td class="a">
                        '+$who+'
                    </td>
                </tr>
                <tr>
                    <th>
                        Sytems
                    </th>
                    <td class="a">
                        '+$sys+'
                    </td>
                </tr>
                <tr>
                    <th>
                        URL
                    </th>
                    <td class="a">
                        '+$urlss+'
                    </td>
                </tr>
                <tr>
                    <th>
                        Impact
                    </th>
                    <td class="a">
                        <p>BlueYonder Cloud Services will be performing maintenance activity on the Server Infrastructure. </br></br>
During the maintenance window, the environment will be unavailable for use. </br></br>
A notification email will be sent prior to the start of the maintenance and upon successful completion of the maintenance activity. 
</p>
                    </td>
                </tr>
                <tr>
                    <th>
                        Maintenance Window
                    </th>
                    <td class="a">
                        '+$time+'
                    </td>
                </tr>
                <tr>
                    <th>
                        Additional Timezone
                    </th>
                    <td class="a">
                        '+$time1+' Coordinated Universal Time</br>
                        '+$time2+' Dublin, Edinburgh, Lisbon, London </br>
                        '+$time3+' Brussels, Copenhagen, Madrid, Paris</br>
                        '+$time4+' Indian Standard Time </br>
                        '+$time5+' Osaka, Sapporo, Tokyo</br>
                        '+$time6+' Canberra, Melbourne, Sydney </br>
                        <p style="color: blue;"><i>&nbsp;&nbsp;Please refer the attachment for additional Time zones.</i></p>
                    </td>
                </tr></table></td></tr>
                <tr><TD>&nbsp;</TD></tr>
                <tr>
                    <td colspan="2">
                        <p style="margin:0in;margin-bottom:.0001pt;">
                        <b>Further questions </b>- Please contact your Technical Account Manager or create a support case by reaching out to <b>Server Support Team</b> at <b>1-214-294-1126</b>
                        </p>
                    </td>
                </tr>
                <tr><TD>&nbsp;</TD></tr>
                <tr style="background:#E6E7E8;text-align: center;">
                    <td style="padding: 5px;" align="center">
                        <p style="margin:0in;margin-bottom:.0001pt;line-height:18.0pt;">
                        <a href="https://blueyonder.com/privacy-policy" target="_blank"><b>Privacy Policy</b></a><strong>, </strong><a href="https://blueyonder.com/terms-of-use" target="_blank"><b>Terms of Use</b></a></br></br>
                        </p>
                        <p style="margin:0in;margin-bottom:.0001pt;line-height:10.5pt;">
                            <span style="font-size:10.0pt;color:#333333;border:none windowtext 1.0pt;padding:0in">
                            Copyright ©  '+$symbol+' 2020 Blue Yonder Group, Inc.<br>
                            All rights reserved.</br></span>
                        </p>
                    </td>
                    <td>
                        <table  cborder="0" cellspacing="0" cellpadding="0" align="center">
                            <tr>
                                <td colspan="6" style="padding: 0px;">
                                    <img border="0" width="180" height="37" style="width:1.875in;height:.3819in" id="Picture_x0020_8" src="cid:Attachment6" alt="Blue Yonder">
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="https://blog.blueyonder.com/" target="_blank">
                                    <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_7" src="cid:Attachment7" alt="Blue Yonder Blog - Fulfill your potential"></a>
                                </td>
                                <td>
                                    <a href="https://www.linkedin.com/company/blueyonderai/" target="_blank"></a>
                                    <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_6" src="cid:Attachment8" alt="LinkedIn"></a>
                                </td>
                                <td>
                                    <a href="https://www.instagram.com/blueyonder__ai/" target="_blank">
                                    <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_5" src="cid:Attachment9" alt="Instagram">
                                    </a>
                                </td>
                                <td>
                                    <a href="https://twitter.com/BlueYonder" target="_blank">
                                    <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_4" src="cid:Attachment10" alt="Twitter">
                                    </a>
                                </td>
                                <td>
                                    <a href="https://www.facebook.com/BlueYonderAI/" target="_blank">
                                    <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_3" src="cid:Attachment11" alt="Facebook"></a>
                                </td>
                                <td>
                                    <a href="https://www.youtube.com/c/BlueYonderAI" target="_blank">
                                    <img border="0" width="15" height="15" style="width:.1527in;height:.1527in" id="Picture_x0020_2" src="cid:Attachment12" alt="YouTube"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>'

$to=$cus.email_to
$cc=$cus.email_cc
$bcc=$cus.email_bcc
$fm="test@jdadelivers.com"
        $SMTPMessage = New-Object System.Net.Mail.MailMessage
        $SMTPServer = "mailout.jdadelivers.com"
        if($to)
        {
        $to=($to -replace ",",";") -split ";"
            foreach($t in $to)
            {
                $SMTPMessage.To.Add($t)
            }
        }
        
        if($cc)
        {
        $cc=($cc -replace ",",";") -split ";"
            foreach($c in $cc)
            {
                $SMTPMessage.CC.Add($c)
            }
        }

        if($bcc)
        {
        $bcc=($bcc -replace ",",";") -split ";"
            foreach($b in $bcc)
            {
                $SMTPMessage.Bcc.Add($bcc)
            }
        }
        
        $SMTPMessage.from=$fm

        $SMTPMessage.subject = "Monthly Maintenance _ Gentle Reminder - 5 day  $who"
        
        $SMTPMessage.IsBodyHTML = $true
        $SMTPClient = New-Object Net.Mail.SmtpClient($SmtpServer, 25)
        $SMTPClient.UseDefaultCredentials = $False
        $path=".\images"
        $image="$path\image0000.png"
        $image1="$path\image0001.png"
        $image2="$path\image0002.png"
        $image3="$path\image0003.png"
        $image4="$path\image0004.png"
        $image5="$path\image0005.png"
        $image6="$path\image0006.png"
        $image7="$path\image0007.png"
        $image8="$path\image0008.png"
        $image9="$path\image0009.png"
        $image10="$path\image0010.png"
        $image11="$path\image0011.png"
        $image12="$path\image0012.png"

        
        $messageBody = [Net.Mail.AlternateView]::CreateAlternateViewFromString($htmlnew, 'text/html')
        # Create a Linked Resource from the logo image
        $imageMimeType = New-Object System.Net.Mime.ContentType("image/png")

        $embeddedImage = New-Object Net.Mail.LinkedResource("$image", $imageMimeType)
        $embeddedImage.ContentId = "Attachment"
        $messageBody.LinkedResources.Add($embeddedImage)
        
        $embeddedImage1 = New-Object Net.Mail.LinkedResource("$image1", $imageMimeType)
        $embeddedImage1.ContentId = "Attachment1"
        $messageBody.LinkedResources.Add($embeddedImage1)

        $embeddedImage2 = New-Object Net.Mail.LinkedResource("$image2", $imageMimeType)
        $embeddedImage2.ContentId = "Attachment2"
        $messageBody.LinkedResources.Add($embeddedImage2)

        $embeddedImage3 = New-Object Net.Mail.LinkedResource("$image3", $imageMimeType)
        $embeddedImage3.ContentId = "Attachment3"
        $messageBody.LinkedResources.Add($embeddedImage3)

        $embeddedImage4 = New-Object Net.Mail.LinkedResource("$image4", $imageMimeType)
        $embeddedImage4.ContentId = "Attachment4"
        $messageBody.LinkedResources.Add($embeddedImage4)

        $embeddedImage5 = New-Object Net.Mail.LinkedResource("$image5", $imageMimeType)
        $embeddedImage5.ContentId = "Attachment5"
        $messageBody.LinkedResources.Add($embeddedImage5)

        $embeddedImage6 = New-Object Net.Mail.LinkedResource("$image6", $imageMimeType)
        $embeddedImage6.ContentId = "Attachment6"
        $messageBody.LinkedResources.Add($embeddedImage6)

        $embeddedImage7 = New-Object Net.Mail.LinkedResource("$image7", $imageMimeType)
        $embeddedImage7.ContentId = "Attachment7"
        $messageBody.LinkedResources.Add($embeddedImage7)

        $embeddedImage8 = New-Object Net.Mail.LinkedResource("$image8", $imageMimeType)
        $embeddedImage8.ContentId = "Attachment8"
        $messageBody.LinkedResources.Add($embeddedImage8)

        $embeddedImage9 = New-Object Net.Mail.LinkedResource("$image9", $imageMimeType)
        $embeddedImage9.ContentId = "Attachment9"
        $messageBody.LinkedResources.Add($embeddedImage9)

        $embeddedImage10 = New-Object Net.Mail.LinkedResource("$image10", $imageMimeType)
        $embeddedImage10.ContentId = "Attachment10"
        $messageBody.LinkedResources.Add($embeddedImage10)

        $embeddedImage11 = New-Object Net.Mail.LinkedResource("$image11", $imageMimeType)
        $embeddedImage11.ContentId = "Attachment11"
        $messageBody.LinkedResources.Add($embeddedImage11)

        $embeddedImage12 = New-Object Net.Mail.LinkedResource("$image12", $imageMimeType)
        $embeddedImage12.ContentId = "Attachment12"
        $messageBody.LinkedResources.Add($embeddedImage12)

        $SMTPMessage.AlternateViews.Add($messageBody) #body
        $SMTPMessage.Attachments.Add($log)
        $SMTPClient.Send($SMTPMessage)

    }
}