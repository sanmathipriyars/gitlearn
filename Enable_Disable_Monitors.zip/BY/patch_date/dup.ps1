﻿$newdata=Import-Csv .\output2021.csv
$olddata=Import-Csv .\final_data.csv
$cus_id=$newdata|select customer_id -Unique
foreach($cus in $cus_id)
{​​​​​
$o=($olddata|Where-Object {$_.customer_id -eq $cus.Customer_ID -and $_.patch_date -ne "1/1/1991"})[0]
$n=($newdata|Where-Object {$_.customer_id -eq $cus.Customer_ID -and $_.month -eq $o.Month})
if($n -ne $o.Patch_Date)
{​​​​​
Write-host "$($o.Patch_Date),$($n.Patch_Date),$($cus.Customer_Id)"
}​​​​​
}​​​​​
