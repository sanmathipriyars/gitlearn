﻿$old=Import-Csv .\final_data_2020.csv
$cus_id=$old|select customer_id -Unique
$newyear="2021"
$WeekDay= "Tuesday" 
$FindNthDay= 2 
$overall=@()
$error_data=@()

#$new=Import-Csv .\final_data.csv

##Function to calculate New dates
function patching_dates($count,$Year){    
$output = @()    
$FindNthDay= 2 
$WeekDay= "Tuesday" 
$months = @(1,2,3,4,5,6,7,8,9,10,11,12)    
#$Year="2021"
foreach($month in $months){         
[datetime]$StrtMonth=$month.ToString()+'/1/'+$Year   
while ($StrtMonth.DayofWeek -ine $WeekDay ) { $StrtMonth=$StrtMonth.AddDays(1) }    
$output += $StrtMonth.AddDays(7*($FindNthDay-1)+$count)    }    
return $output
} 
$month_ns=(New-Object System.Globalization.DateTimeFormatInfo).MonthNames


foreach($cus in $cus_id)#|Where-Object {$_.customer_id -eq "2"})
{
$cus.Customer_Id
$data=$old|Where-Object {$_.customer_id -eq $cus.Customer_Id -and ($_.Patch_Date -ne "1/1/1991" -and $_.Patch_Date -ne "01/01/1991")}|select *
if($data.Count)
{
$d1=$data[0]
$d2=$data[1]
    if($d1 -and $d2)
    {
        $M1=$d1.Month
        $Y1=$d1.Year
        [datetime]$StrtMonth="$M1/1/$Y1"
        while($StrtMonth.DayofWeek -ine $WeekDay ) 
        { $StrtMonth=$StrtMonth.AddDays(1) }
        $sT_nM=$StrtMonth.AddDays(7*($FindNthDay-1))
        $d1_ct=(NEW-TIMESPAN –Start $sT_nM –End $d1.Patch_Date).Days
        
        $M2=$d2.Month
        $Y2=$d2.Year
        [datetime]$StrtMonth="$M2/1/$Y2"
        while($StrtMonth.DayofWeek -ine $WeekDay ) 
        { $StrtMonth=$StrtMonth.AddDays(1) }
        $sT_dM=$StrtMonth.AddDays(7*($FindNthDay-1))
        $d2_ct=(NEW-TIMESPAN –Start $sT_dM –End $d2.Patch_Date).Days
        
        if($d1_ct -eq $d2_ct)
        {
            $dates=patching_dates -count $d1_ct -Year $newyear
            $result=@()
           # $months=(New-Object System.Globalization.DateTimeFormatInfo).MonthNames
            $i=0
            foreach($dt in $dates)
            {
              $result+= [PSCustomObject]@{
              'Customer_ID'=$d1.Customer_Id
              'E_ID'=$d1.E_ID
              'Year'=$newyear
              'Month'=$month_ns[$i]
              'Day_Date'=Get-Date $dt -Format "dd"
              'S_ID'=''
              'Patch_Date'=Get-Date $dt -Format "MM/dd/yyy"
              'state'='new'
              }
            $i++
            }
            $overall+=$result
        }
        else
        {
            if($d1.Day_Date -eq $d2.Day_Date)
            {
                if((Get-Date $([datetime]$d1.Patch_Date) -Format "MMMM") -eq $d1.Month)
                {
                    $months = @(1,2,3,4,5,6,7,8,9,10,11,12)    
                    $result=@()
                    #$Year="2021"
                    foreach($month in $months)
                    {
                    $month
                        [datetime]$StrtMonth=$month.ToString()+'/'+$d1.Day_Date+'/'+$newyear
                        $result+= [PSCustomObject]@{
                          'Customer_ID'=$d1.Customer_Id
                          'E_ID'=$d1.E_ID
                          'Year'=$newyear
                          'Month'=Get-Date -Month $month -Format MMMM
                          'Day_Date'=Get-Date $StrtMonth -Format "dd"
                          'S_ID'=''
                          'Patch_Date'=Get-Date $StrtMonth -Format "MM/dd/yyy"
                          'state'='new'
                          }
                    }
                    $overall+=$result
                }
                else
                {
                    if((Get-Date $([datetime]$d1.Patch_Date) -Format "MMMM") -eq $d1.Month)
                    {
                        $months = @(1,2,3,4,5,6,7,8,9,10,11,12)    
                        $result=@()
                        #$Year="2021"
                        foreach($month in $months)
                        {
                            [datetime]$StrtMonth=$month.ToString()+'/'+$d1.Day_Date+'/'+$newyear
                            $result+= [PSCustomObject]@{
                              'Customer_ID'=$d1.Customer_Id
                              'E_ID'=$d1.E_ID
                              'Year'=$newyear
                              'Month'=Get-Date -Month $month -Format MMMM
                              'Day_Date'=Get-Date $StrtMonth -Format "dd"
                              'S_ID'=''
                              'Patch_Date'=Get-Date $StrtMonth -Format "MM/dd/yyy"
                              'state'='new'
                              }
                        }
                        $overall+=$result
                    }
                    else
                    {
                        $months=(New-Object System.Globalization.DateTimeFormatInfo).MonthNames
                        $month_no=([array]::indexof($months,$d1.Month)+1)+1   ##+1 for index +1 for next month
                        $nxt_month="$month_no/$($d1.Day_Date)/$($d1.Year)"
                        if($d1.Patch_Date -eq $nxt_month)
                        {
                           $months = @(1,2,3,4,5,6,7,8,9,10,11,12)    
                           $result=@()
                           #$Year="2021"
                           foreach($month in $months)
                           {
                            $month+=1
                            if($month -eq 13){$month=1}
                               [datetime]$StrtMonth=$month.ToString()+'/'+$d1.Day_Date+'/'+$newyear
                               $result+= [PSCustomObject]@{
                                 'Customer_ID'=$d1.Customer_Id
                                 'E_ID'=$d1.E_ID
                                 'Year'=$newyear
                                 'Month'=Get-Date -Month $month -Format MMMM
                                 'Day_Date'=Get-Date $StrtMonth -Format "dd"
                                 'S_ID'=''
                                 'Patch_Date'=Get-Date $StrtMonth -Format "MM/dd/yyy"
                                 'state'='new'
                                 }
                           }
                           $overall+=$result
                        }
                        else
                        {
                        Write-Host "Unable to find format $($d1.Customer_Id)"
                        $error_data+= [PSCustomObject]@{
                                 'Customer_ID'=$d1.Customer_Id
                                 'Error'="Unable to find format $($d1.Customer_Id)"
                                 }
                        }
                    }
                }
            }
            else
            {
            Write-Host "Date formats doesn't match $($d1.Customer_Id)"
            $error_data+= [PSCustomObject]@{
                     'Customer_ID'=$d1.Customer_Id
                     'Error'="Date formats doesn't match $($d1.Customer_Id)"
                     }
            }
        }
    }
    else
    {
    Write-Host "d1 or d2 is empty" -ForegroundColor Red
    $error_data+= [PSCustomObject]@{
         'Customer_ID'=$d1.Customer_Id
         'Error'="d1 or d2 is empty $($d1.Customer_Id)"
         }
    }
}
else
{
Write-Host "$($cus.Customer_Id) Doesn't have any data" -ForegroundColor Red
$error_data+= [PSCustomObject]@{
    'Customer_ID'=$cus.Customer_Id
    'Error'="$($cus.Customer_Id) Doesn't have any data"
    }
}
}
$overall|Export-Csv .\output2021.csv -NoTypeInformation


<#

$newdata=Import-Csv .\output2021.csv
$olddata=Import-Csv .\final_data.csv
$cus_id=$newdata|select customer_id -Unique
foreach($cus in $cus_id){
$o=($olddata|Where-Object {($_.customer_id -eq $cus.Customer_ID) -and ($_.patch_date -ne "1/1/1991")})[0]
$n=($newdata|Where-Object {($_.customer_id -eq $cus.Customer_ID) -and ($_.month -eq $o.Month)})
if($n -notlike $o.Patch_Date)
{​​​​​
Add-content -Value "$($o.Patch_Date),$($n.Patch_Date),$($cus.Customer_Id)" -Path ".\rep.csv"
}​​​​​
}​​​​​#>