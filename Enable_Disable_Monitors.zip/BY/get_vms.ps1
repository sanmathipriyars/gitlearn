﻿Connect-AzAccount -Credential (Get-Credential)
$subscription=Get-AzSubscription
$path="\\vincromi0019\C$\Azure_scripts"
get-date
$overall=@()
foreach($sub in $subscription)
{
    Select-AzSubscription -Subscription $sub.Id
    $allvms=Get-AzVM
    if($allvms)
    {

        $AllVMTags =  @() 
        foreach ($virtualmachine in $allvms) 
        { 
            $tags = $virtualmachine.Tags 
            $tKeys = $tags | select -ExpandProperty keys 
            foreach ($tkey in $tkeys) 
            { 
              if ($AllVMTags -notcontains $tkey.ToUpper()) { $AllVMTags += $tkey.ToUpper() } 
            } 
        }
        
        #for($i=$($AllVMTags.Count);$i -lt 22; $i++) { $AllVMTags += "Az_VMTag$i"  } #Default Header value
        for($i=$($AllVMTags.Count);$i -lt 30; $i++) { $AllVMTags += "Az_VMTag$i"  } #Default Header value
        
        $AzureVMs = foreach ($virtualmachine in $allvms) 
        { 
            $location = $virtualmachine.Location 
            $rgname = $virtualmachine.ResourceGroupName 
            $vmname = $virtualmachine.Name 
 
            # Format Tags, sample: "key : Value <CarriageReturn> key : value "   TAGS keys are converted to UpperCase 
            $taglist = ' ' 
            $ThisVMTags = @(' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ')  # Array of VMTags matching the $AllVMTags (Header) 
            $tags = $virtualmachine.Tags 
            $tKeys = $tags | select -ExpandProperty keys 
            $tvalues = $tags | select -ExpandProperty values 
            if($tags.Count -eq 1)  
            { 
                  $taglist = $tkeys+":"+$tvalues 
                  $ndx = [array]::IndexOf($AllVMTags,$tKeys.ToUpper())  # Find position of header matching the Tag key 
                  $ThisVMTags[$ndx] = $tvalues 
            } 
            else 
              { 
                For ($i=0; $i -lt $tags.count; $i++)  
                { 
                  $tkey = $tkeys[$i] 
                  $tvalue = $tvalues[$i] 
                  $taglist = $taglist+$tkey+":"+$tvalue+"`n" 
                  $ndx = [array]::IndexOf($AllVMTags,$tKey.ToUpper())   # Find position of header matching the Tag key 
                  $ThisVMTags[$ndx] = $tvalue 
                } 
              } 

# Create custom PS objects and return all these properties for this VM 
            [pscustomobject]@{ 
                            Az_Location = $virtualmachine.Location 
                            Az_ResourceGroup = $virtualmachine.ResourceGroupName 
                            Az_Name = $virtualmachine.Name 
                            Az_Status = $vmstatus 
                            Az_Statuscode = $virtualmachine.StatusCode 
                            Az_AvailabilitySet = $ASet 
                            Az_Size = $virtualmachine.HardwareProfile.VmSize 
                            Az_Cores = $VMCores 
                            Az_Memory = $VMMem 
                            Az_OSType = $virtualmachine.StorageProfile.OsDisk.OsType 
                            Az_VNicNames = $NICName -join "`n" 
                            Az_VNicProvisioningState = $NICProvState -join "`n" 
                            Az_VNicPrivateIPs = $NICPrivateIP -join "`n" 
                            Az_vNicPrivateIPAllocMethods = $NICPrivateAllocationMethod -join "`n" 
                            Az_VirtualNetworks = $NICVnet -join "`n" 
                            Az_Subnets = $NICSubnet -join "`n" 
                            Az_VNicPublicIP = $NICPublicIP 
                            Az_VNicPublicIPAllocMethod = $NICPublicAllocationMethod 
                            Az_VM_Instance_SLA = $AllVMDisksPremium
                            Az_OSDisk = $OSDiskName 
                            Az_OSDiskSize = $OSDiskSize
                            Az_OSDiskTier = $OSDiskTier  
                            Az_OSDiskRepl = $OSDiskRepl 
                            Az_DataDisks = $DataDiskObj.Name -join "`n" 
                            Az_DataDisksSize = $DataDiskObj.Size -join "`n" 
                            Az_DataDisksTier = $DataDiskObj.Tier -join "`n"
                            Az_DataDisksRepl = $DataDiskObj.Repl -join "`n"
                            Az_VMTags = $taglist 
                            $AllVMTags[0] = $ThisVMTags[0] 
                            $AllVMTags[1] = $ThisVMTags[1] 
                            $AllVMTags[2] = $ThisVMTags[2] 
                            $AllVMTags[3] = $ThisVMTags[3] 
                            $AllVMTags[4] = $ThisVMTags[4] 
                            $AllVMTags[5] = $ThisVMTags[5] 
                            $AllVMTags[6] = $ThisVMTags[6] 
                            $AllVMTags[7] = $ThisVMTags[7] 
                            $AllVMTags[8] = $ThisVMTags[8] 
                            $AllVMTags[9] = $ThisVMTags[9] 
                            $AllVMTags[10] = $ThisVMTags[10] 
                            $AllVMTags[11] = $ThisVMTags[11] 
                            $AllVMTags[12] = $ThisVMTags[12] 
                            $AllVMTags[13] = $ThisVMTags[13] 
                            $AllVMTags[14] = $ThisVMTags[14] 
			    $AllVMTags[15] = $ThisVMTags[15] 
                            $AllVMTags[16] = $ThisVMTags[16] 
                            $AllVMTags[17] = $ThisVMTags[17] 
                            $AllVMTags[18] = $ThisVMTags[18] 
                            $AllVMTags[19] = $ThisVMTags[19] 
                            $AllVMTags[20] = $ThisVMTags[20] 
                            $AllVMTags[21] = $ThisVMTags[21] 
                            $AllVMTags[22] = $ThisVMTags[22] 
                            $AllVMTags[23] = $ThisVMTags[23] 
                            $AllVMTags[24] = $ThisVMTags[24] 
                            $AllVMTags[25] = $ThisVMTags[25] 
                            $AllVMTags[26] = $ThisVMTags[26] 
                            $AllVMTags[27] = $ThisVMTags[27] 
                            $AllVMTags[28] = $ThisVMTags[28] 
                            $AllVMTags[29] = $ThisVMTags[29] 
                         } 
 
        }  #Array $AzureVMs 
 
    $overall+=$AzureVMs
    }
}
$overall|Export-Csv "$path\azure_vms.csv" -NoTypeInformation
get-date