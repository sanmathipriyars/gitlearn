﻿$SQLServer = "" #dbservername
$SQLDBName = "bppl"
$uid = ""  #username
$pwd = ""  #password
$job_name="DBM - DBCC - All Allowed Databases"  #Enable job

function SQL-Query($SqlQuery, $SQLServer,$SQLDBName,$uid,$pwd)
{
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; User ID = $uid; Password = $pwd;"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)
return $DataSet.Tables[0]
}

$upd_seg = "update ape_execution_queue_segment set active_flag = 'Y'"
$upd_seg_res=SQL-Query -SqlQuery $upd_seg -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd

$insert_query="insert into hosting_stats.dbo.hs_service_history values(@@servername,@@servername,'$SQLDBName','$SQLDBName',getdate(),'enabled ape queue segments')"
$insert_res=SQL-Query -SqlQuery $insert_query -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd

$enable_job="EXEC msdb.dbo.sp_update_job @job_name = N'$job_name',@enabled = 1 ;GO"
$enable_job_res=SQL-Query -SqlQuery $enable_job -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd
