﻿$SQLServer = "" #dbservername
$SQLDBName = "bppl"
$uid = ""  #username
$pwd = ""  #password
function SQL-Query($SqlQuery, $SQLServer,$SQLDBName,$uid,$pwd)
{
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; User ID = $uid; Password = $pwd;"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)
return $DataSet.Tables[0]
}

$precheck = "select * from ape_execution_queue_segment"
$pre=SQL-Query -SqlQuery $precheck -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd

$upd_seg = "update ape_execution_queue_segment set active_flag = 'n'"
$upd_seg_res=SQL-Query -SqlQuery $upd_seg -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd

$postcheck="select segment_name,active_flag from ape_execution_queue_segment"
$post=SQL-Query -SqlQuery $postcheck -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd
$upd_set_res|ft

$insert_query="insert into hosting_stats.dbo.hs_service_history values(@@servername,@@servername,'bppl','bppl',getdate(),'disabled ape queue segments')"
$insert_res=SQL-Query -SqlQuery $insert_query -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd

$disable_job="EXEC msdb.dbo.sp_update_job @job_name = N'DBM - DBCC - All Allowed Databases', @enabled = 0 ;GO"
$disable_job_res=SQL-Query -SqlQuery $disable_job -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd