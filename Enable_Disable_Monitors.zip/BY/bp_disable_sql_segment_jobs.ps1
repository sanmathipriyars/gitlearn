﻿$SQLServer = "DCYCTXDB01.jdadelivers.com"
$SQLDBName = "Email_Notification"
$uid = "sa"
$pwd = "sa1234"
function SQL-Query($SqlQuery, $SQLServer,$SQLDBName,$uid,$pwd)
{
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; User ID = $uid; Password = $pwd;"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)
return $DataSet.Tables[0]
}

$SqlQuery = "SELECT * from Patching_Dates where Year='2020'"
$s_2020=SQL-Query -SqlQuery $SqlQuery -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd
$SqlQuery = "SELECT * from Patching_Dates where Year='2021'"
$s_2021=SQL-Query -SqlQuery $SqlQuery -SQLServer $SQLServer -SQLDBName $SQLDBName -uid $uid -pwd $pwd
#|Export-Csv "\\DLJDAMGMTROMINAS01.jdadelivers.com\ROMI_Share\profiles\1028742\Desktop\final_data_2020.csv" -NoTypeInformation
#SCPO-Transition-POD@blueyonder.com;csscpoappteam@blueyonder.com