from datetime import datetime
import pyodbc
import csv
import sys
conn = pyodbc.connect('Driver={SQL Server};'
                      'Server=DCYCTXDB01.jdadelivers.com;'
                      'Database=Email_Notification;'
                      'uid=sa;pwd=sa1234;')
now = datetime.now()
now = now.strftime('%#m/%#d/%Y')
#now = '7/21/2020'
print(now)
cursor = conn.cursor()
#customer_name = sys.argv[1]
#customer_name = "Al-Futtaim Private Company LLC"

sql = f"Select * from Customer"
#f"SELECT Customer.Customer_Name,customer.E_ID,Customer_Info.Customer_Maintenance,patching_Dates.patch_Date,Customer_Info.Email_To,Customer_Info.Email_Cc,Customer_Info.Email_Bcc,Customer_Info.URL,Customer_Info.[Systems/Services_Affected] FROM Customer INNER JOIN Patching_Dates ON Customer.Customer_Id = Patching_Dates.Customer_Id INNER JOIN Customer_Info ON Customer.Customer_Id =Customer_Info.Customer_Id WHERE (Patching_Dates.Patch_Date='{now}')"
result = cursor.execute(sql)
print(result)
#print(result.fetchall())
for i in result.fetchall():
    print(i)
