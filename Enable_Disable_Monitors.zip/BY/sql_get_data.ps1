﻿$SQLServer = "DCYCTXDB01.jdadelivers.com"
$SQLDBName = "Email_Notification"
$uid = "sa"
$pwd = "sa1234"
$SqlQuery = "SELECT * from customer_details"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; User ID = $uid; Password = $pwd;"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)
$DataSet.Tables[0]
#|Export-Csv "\\DLJDAMGMTROMINAS01.jdadelivers.com\ROMI_Share\profiles\1028742\Desktop\2021_backup_1.csv" -NoTypeInformation
#SCPO-Transition-POD@blueyonder.com;csscpoappteam@blueyonder.com
#$data=Get-content ".\data_replaced.txt"
#$SQLServer = "DCYCTXDB01.jdadelivers.com"
#$SQLDBName = "Email_Notification"
#$uid = "sa"
#$pwd = "sa1234"
#foreach($d in $data)
#{
#$SqlQuery = "Update Patching_Dates set Day_Date='28', Patch_date='2/28/2021' where Customer_Id='$d' and Patch_date='2/15/2021' and Year='2021' and Month='February'"
#$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
#$SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; User ID = $uid; Password = $pwd;"
#$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
#$SqlCmd.CommandText = $SqlQuery
#$SqlCmd.Connection = $SqlConnection
#$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
#$SqlAdapter.SelectCommand = $SqlCmd
#$DataSet = New-Object System.Data.DataSet
#$SqlAdapter.Fill($DataSet)
#
#$DataSet.Tables[0]
#}
Update customer_details set team='RP-RPS-Hosting-App-Info@blueyonder.com' where id ='199'

$cus=$cus|Where-Object {$_.e_id -eq 2}
$data=get-content \\DLJDAMGMTROMINAS01.jdadelivers.com\ROMI_Share\profiles\1028742\Desktop\find_cid.txt
$overall=@()
foreach($d in $data)
{
 $overall+=$cus|Where-Object {$_.customer_name -eq $d}|select customer_name,customer_id 
}

$overall|Where-Object{$_.customer_id -ne '1175'}|export-csv "new_data.csv" -NoTypeInformation
#1175 Customer to be 


$tt=Import-Csv .\new_data.csv
$SQLServer = "DCYCTXDB01.jdadelivers.com"
$SQLDBName = "Email_Notification"
$uid = "sa"
$pwd = "sa1234"
foreach($t in $tt)
{
$SqlQuery = "Update Patching_Dates set Day_Date='13', Patch_date='3/13/2021' where Customer_Id='$($t.Customer_Id)' and Patch_date='3/7/2021' and Year='2021' and Month='March'"
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; User ID = $uid; Password = $pwd;"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)

$DataSet.Tables[0]
}