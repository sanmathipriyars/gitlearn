﻿<#################### Disable ##############################>
Import-Module zabbixPoshAPI

<#
Input.csv

Server,hostid
server1,1000000
server2,1000001
#>
$zabbixServer="veus2core0806"
$username=""
$Password=""
$server = Import-Csv "C:\input.csv"
$logfile="C:\disable_host_$(Get-Date -Format 'dd_MM_yyyy_hh_mm_ss').txt"

### Connection to Zabbix API ###
try
{
    $hostURL = "https://$zabbixServer.jdadelivers.com/zabbix/api_jsonrpc.php" 
    $connect = connect-Zabbix_new -zabbixApiURL $hostURL -username $username -password $password

    $data=""
    foreach($c in $server)
    {
        if($data)
        {$data+=","}
        $data+="{`"hostid`": `"$($c.hostid)`"}"
    }

            $disable_host = "{
                `"jsonrpc`": `"2.0`",
                `"method`": `"host.massupdate`",
                `"params`": {
                    `"hosts`": [$data],
                    `"status`": 1
                    },
                    `"auth`": `"$($connect.result)`",
                    `"id`": 1
                }"
        
            $disable_res = getJSON -url $hostURL $disable_host
            if($disable_res.result)
            {
            Add-Content -Value "Host Disabled $($server.server -join ", " ) Hostid:$($disable_res.result.hostids)" -Path $logfile
            }
            else
            {
                Add-Content -Value "Error: Host Disabled $($disable_res.error)" -Path $logfile
                $errors += "Error: Host Disabled $($disable_res.error)"
            }
}
catch
{
    Add-Content -Value "Error Connecting Zabbix Server : $($ZabbixServer)" -Path $logfile
    $errors += "Error: Connecting Zabbix Server : $($ZabbixServer)"
}

